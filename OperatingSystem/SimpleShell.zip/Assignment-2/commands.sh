cat fib.c | wc -l
cat helloworld.c | grep print | wc -l